package com.eTicaret.shoppingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TkShoppingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TkShoppingAppApplication.class, args);
	}

}
