package com.eTicaret.shoppingapp.product.model;

public class ProductResponse {
    private String id;

}
