package com.eTicaret.shoppingapp.product.domain;

public class ProductDetails {


}
