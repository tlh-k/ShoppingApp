package com.eTicaret.shoppingapp.product.domain;



public class Product {

    private String id;
    private String productName;
    private String productCode;
    private Boolean active;


}
