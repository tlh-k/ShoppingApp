package com.eTicaret.shoppingapp.product.service;

public interface ProductService {
}
