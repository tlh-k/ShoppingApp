package com.eTicaret.shoppingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TkShoppingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
